cs101
=====

Course code for Introduction to Computer Science class

Take the class at https://www.udacity.com/course/cs101

Lesson 9: How to Manage Complexity. Modules, types, classes

Lesson 10: How to Reuse Classes. Inheritance

Lesson 11: Programs in the Real World. File IO, and Exceptions