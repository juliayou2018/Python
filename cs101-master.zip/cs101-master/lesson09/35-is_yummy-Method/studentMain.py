# Please edit the Restaurant class in the file restaurant.py

from restaurant import Restaurant

# These are test cases

mcdowells = Restaurant("McDowell's Hamgurger Emporium")
mcdowells.is_yummy()

chez_bananas = Restaurant("Chez Bananas Crib of Contentment")
chez_bananas.is_yummy()