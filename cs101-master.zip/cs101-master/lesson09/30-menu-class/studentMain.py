# Please define the class Menu in the menu.py file
from menu import Menu

# the following two variables should be instances of the class Menu

lunch =

dinner =
