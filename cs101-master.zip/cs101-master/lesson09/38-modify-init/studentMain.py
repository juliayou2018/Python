# Please edit the Restaurant class in the file restaurant.py

from restaurant import Restaurant

# These are test cases

mcdowells = Restaurant("McDowell's Hamgurger Emporium", "Cleo McDowell", "Chef Queasy")


# test case:
print mcdowells.name, mcdowells.owner, mcdowells.chef