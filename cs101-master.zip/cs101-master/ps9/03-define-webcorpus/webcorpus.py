###
### webcorpus.py
###

### Define the WebCorpus class here:
