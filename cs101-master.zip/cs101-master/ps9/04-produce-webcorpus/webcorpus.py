###
### webcorpus.py
###

class WebCorpus:
    def __init__(self):
        self.index = {}
        self.graph = {}
