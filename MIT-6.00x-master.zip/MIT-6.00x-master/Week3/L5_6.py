def lenIter(aStr):
    length = 0
    for char in aStr:
        length += 1
    return length
